import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

type Props = {}

const Comentario = (props: Props) => {
  return (
    <View>
      <Text>Comentario</Text>
    </View>
  )
}

export default Comentario

const styles = StyleSheet.create({})