import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

type Props = {}

const Fauna = (props: Props) => {
  return (
    <View>
      <Text>Fauna</Text>
    </View>
  )
}

export default Fauna

const styles = StyleSheet.create({})