import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

type Props = {}

const Flora = (props: Props) => {
  return (
    <View>
      <Text>Flora</Text>
    </View>
  )
}

export default Flora

const styles = StyleSheet.create({})