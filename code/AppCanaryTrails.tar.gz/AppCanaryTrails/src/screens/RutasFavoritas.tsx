import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

type Props = {}

const RutasFavoritas = (props: Props) => {
  return (
    <View>
      <Text>RutasFavoritas</Text>
    </View>
  )
}

export default RutasFavoritas

const styles = StyleSheet.create({})