import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

type Props = {}

const Enciclopedia = (props: Props) => {
  return (
    <View style={{flex:1, backgroundColor:'#9D8DF1'}}>
      <Text>Enciclopedia</Text>
    </View>
  )
}

export default Enciclopedia

const styles = StyleSheet.create({})