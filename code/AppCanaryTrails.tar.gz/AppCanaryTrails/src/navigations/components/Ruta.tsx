import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

type Props = {}

const Ruta = (props: Props) => {

  return (
    <View>
      <Text>Ruta</Text>
    </View>
  )
}

export default Ruta

const styles = StyleSheet.create({})