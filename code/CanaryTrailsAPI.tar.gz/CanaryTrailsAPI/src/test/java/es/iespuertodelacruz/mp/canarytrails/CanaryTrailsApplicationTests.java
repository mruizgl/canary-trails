package es.iespuertodelacruz.mp.canarytrails;

import org.junit.jupiter.api.Test;

class CanaryTrailsApplicationMainTest {

	@Test
	void mainMethodShouldRunWithoutExceptions() {
		CanaryTrailsApplication.main(new String[] {});
	}
}
