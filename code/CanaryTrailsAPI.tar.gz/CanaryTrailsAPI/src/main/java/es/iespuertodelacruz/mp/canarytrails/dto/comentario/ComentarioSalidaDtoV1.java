package es.iespuertodelacruz.mp.canarytrails.dto.comentario;

public record ComentarioSalidaDtoV1(
        Integer id,
        String titulo,
        String descripcion,
        String nombreUsuario
) {}