package es.iespuertodelacruz.mp.canarytrails.dto.rutafavorita;

public record ModificarRutaFavoritaDto(
        int idUsuario,
        int idRuta
) {
}
