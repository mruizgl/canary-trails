package es.iespuertodelacruz.mp.canarytrails;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CanaryTrailsApplication {

	public static void main(String[] args) {
		SpringApplication.run(CanaryTrailsApplication.class, args);
	}

}
