package es.iespuertodelacruz.mp.canarytrails.dto.usuario.auth;

public record UsuarioLoginDto (
        String nombre,
        String password
) {}
