package es.iespuertodelacruz.mp.canarytrails;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CanaryTrailsApplicationTests {

	@Test
	void contextLoads() {
	}

}
